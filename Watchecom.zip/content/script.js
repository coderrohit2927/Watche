// Get video player and playlist elements
var player = document.getElementById("video-player");
var playlist = document.getElementById("video-playlist");

// Add click event listener to playlist
playlist.addEventListener("click", function(event) {
  event.preventDefault();

  // Get selected video URL
  var videoURL = event.target.getAttribute("href");

  // Update video player src attribute
  player.setAttribute("src", videoURL);
});
