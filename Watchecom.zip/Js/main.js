 const text = document.querySelector(".sec-text");

        const textLoad = () => {
            setTimeout(() => {
                text.textContent = "Doremon";
            }, 0);
            setTimeout(() => {
                text.textContent = "Shinchan";
            }, 2000);
            setTimeout(() => {
                text.textContent = "Ninja hattori";
            }, 8000); //1s = 1000 milliseconds
        }

        textLoad();
        setInterval(textLoad, 5000);